from setuptools import setup

setup(

    name = "calculos_basico",
    version="1.0",
    description = "Paquete con funciones de operaciones aritmeticas básicas", 
    author = "isc.Joaquin Sayago Trujillo",

    author_email = "isc.jsayago@hotmail.com",
    url = "Sin sitio web disponible",

    packages = ["paquetes","paquetes.basicos"]
)