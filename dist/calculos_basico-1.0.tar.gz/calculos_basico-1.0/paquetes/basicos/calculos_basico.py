def sumar(num1,num2):
    print("El resultado de la suma es: ",num1+num2)

def restar(num1,num2):
    print("El resultado de la resta es: ",num1-num2)

def multiplicar(num1,num2):
    print("El resultado de la multiplicación es: ",num1*num2)

def dividir(num1,num2):
    print("El resultado de la divisió es: ",num1/num2)